
class Ant
	attr_accessor :ant_type, :anthill_id, :can_move, :x, :y
	def initialize
	end
end