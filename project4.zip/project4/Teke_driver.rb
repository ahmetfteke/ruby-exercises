require_relative 'Meadow.rb'

m = Meadow.instance
m.meadow_template
