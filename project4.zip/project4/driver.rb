require_relative 'Meadow'

def main
	my_meadow= Meadow.instance
	my_meadow.meadow_setup()

	#my_meadow.move_ant
	#my_meadow.

	# turn_counter=0

	# my_meadow.cycle do |cell|
	# 	cell.ants.each do |ant|
	# 		ant.do_action()
			
	# 	end
	# 	cell.hill.do_action()
	# 	turn_counter=turn_counter+1
 # 	end
end
main


