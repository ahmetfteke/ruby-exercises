class Room
	attr_accessor :idle
	def initialize()
		@idle = true
	end
end
