class Response
	def response(user_answer, responses)
		raise NoMethodError # interface for response strategies
	end
end