require "observer"

class User          ### Periodically fetch a stock price.
  include Observable

  def initialize(symbol)
    @symbol = symbol
  end

  def converse
    last_answer = nil
    loop do
      answer = gets().chomp()
      if answer != last_answer
        changed                 # notify observers
        last_answer = answer
        notify_observers(answer)
      end
      sleep 1
    end
  end
end


class Chatbot         ### An abstract observer of Ticker objects.
  def initialize()
  end
  def enterChat(user)
    user.add_observer(self)
  end
end

class AngryChatbot < Chatbot
  def update(answer)       # callback for observer
    puts "Your answer changed."
  end
end


puts("\nPlease enter your name: ")
user_name = gets().chomp()
user = User.new(user_name)
bots = []
#bots << HappyChatbot.new()
bots << AngryChatbot.new()
#bots << DepressedChatbot.new()

bots.each { |b|
  b.enterChat(user)
}
puts user.count_observers
while user.count_observers > 0
  user.converse
end