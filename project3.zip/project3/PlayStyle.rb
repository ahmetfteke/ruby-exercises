class PlayStyle
	def play
		raise NoMethodError
	end
end